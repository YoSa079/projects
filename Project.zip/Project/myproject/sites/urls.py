from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.giris, name="login"),
    path('logout/', views.cikis, name="cikis"),
    path('register/', views.kaydol, name="kaydol"),
    path('', views.index, name='index'),
    path('post/<str:pk>/', views.viewPost, name='post'),
    path('nwpost/', views.fotoEkle, name='nwpost'),
    path('edit_profile/', views.profil_edit, name='edit'),
    path('change_password/', views.change_password, name='change_password'),
    path("delete<int:id>/", views.delete, name="delete"),
    path("deletep<int:id>/", views.deletep, name="deletep"),
]
