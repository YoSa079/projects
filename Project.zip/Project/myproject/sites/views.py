from django.core.exceptions import ObjectDoesNotExist
from django.http import Http404
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import DeleteView, DetailView
from django.views.generic import FormView
from django.views.generic.detail import SingleObjectMixin
from .models import Post, Comment
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from .forms import CustomUserCreationForm, EditProfileForm, CommentForm
from django.contrib import messages
from django.contrib.auth.forms import PasswordChangeForm
import datetime
from django.urls import reverse


# Create your views here.

def profil_edit(req):
    if req.method == 'POST':
        form = EditProfileForm(req.POST, instance=req.user)
        if form.is_valid():
            form.save()
            messages.success(req, ('Profiliniz başarıyla güncellendi'))
            return redirect('index')
    else:  # passes in user information
        form = EditProfileForm(instance=req.user)

    context = {'form': form}
    return render(req, 'edit_profile.html', context)


def change_password(req):
    if req.method == 'POST':
        form = PasswordChangeForm(data=req.POST, user=req.user)
        if form.is_valid():
            form.save()
            update_session_auth_hash(req, form.user)
            messages.success(req, ('Şifreniizi değiştirdiniz'))
            return redirect('index')
    else:  # passes in user information
        form = PasswordChangeForm(user=req.user)

    context = {'form': form}
    return render(req, 'change_password.html', context)


def giris(req):
    page = 'login'
    if req.method == 'POST':
        username = req.POST['username']
        password = req.POST['password']
        user = authenticate(req, username=username, password=password)
        if user is not None:
            login(req, user)
            return redirect('index')
    return render(req, 'login_register.html', {'page': page})


def cikis(req):
    logout(req)
    return redirect('index')


def kaydol(req):
    page = 'register'
    form = CustomUserCreationForm()
    if req.method == 'POST':
        form = CustomUserCreationForm(req.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.save()
            if user is not None:
                login(req, user)
                return redirect('index')

    context = {'form': form, 'page': page}
    return render(req, 'login_register.html', context)


def index(req):
    posts = Post.objects.all()
    comments = Comment.objects.all()

    context = {'posts': posts, "comments": comments}
    return render(req, 'home.html', context)


@login_required(login_url='login')
def viewPost(req, pk):
    try:
        post = Post.objects.get(id=pk)
    except ObjectDoesNotExist:
        raise Http404
    comment_form = CommentForm(req.POST or None)
    comments = Comment.objects.filter(post_id=int(pk))
    if comment_form.is_valid():
        comment = comment_form.save(commit=False)
        comment.post = post
        comment.name = req.user
        comment.save()
        comment_form = CommentForm()
        messages.success(req, "Yorumunuz başarıyla atıldı!")

    return render(req, 'post.html', {'post': post, "form": comment_form, "comments": comments})


@login_required(login_url='login')
def fotoEkle(req):
    user = req.user
    if req.method == 'POST':
        data = req.POST
        image = req.FILES.get('image')
        x = datetime.datetime.now()
        y = False
        try:
            if data["check"] == "on":
                y = True
        finally:
            post = Post.objects.create(
                description=data['description'],
                image=image,
                yorumA=y,
                author=user,
                time=x.strftime("%d/%m/%Y %H:%M"),
            )
            return redirect('index')
    context = {}
    return render(req, 'add.html', context)


@login_required(login_url="login")
def delete(request, id):
    Comment.objects.filter(id=id).delete()
    return redirect("index")


@login_required(login_url="login")
def deletep(request, id):
    Post.objects.filter(id=id).delete()
    messages.success(request, "Postunuz silindi")
    return redirect("index")
